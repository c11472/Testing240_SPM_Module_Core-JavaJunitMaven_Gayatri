package com.custome.exceptions;

import java.util.Scanner;


public class AgeValidation extends UnderAgeException {
	public static void main(String args[]) {
		
		int age;
		Scanner c = new Scanner(System.in);
		
		age=c.nextInt();
		
		if(age<18) {
			throw new UnderAgeException();

		}
		else {
			System.out.println("The user can cast vote");
		}
		
		
	}
	

}
