package com.programs.day3;

public class CalculateArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircleDetails obj = new CircleDetails();
		
		obj.setRadius(2);
		int r1=obj.GetRadius();
		System.out.println(3.14*r1*r1);

	}
}
