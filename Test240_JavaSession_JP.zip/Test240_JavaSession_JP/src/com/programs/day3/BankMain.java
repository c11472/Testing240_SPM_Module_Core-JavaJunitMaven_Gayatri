package com.programs.day3;

public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LocalBank lb = new LocalBank();
		
		lb.Display_Details("New_B_ICICI", "BBSR", "7694");

	}

}
