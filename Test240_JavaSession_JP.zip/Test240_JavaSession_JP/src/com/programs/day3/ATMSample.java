package com.programs.day3;

public interface ATMSample {
	abstract void cardNumber();
	abstract void pinNumber();
	

}
