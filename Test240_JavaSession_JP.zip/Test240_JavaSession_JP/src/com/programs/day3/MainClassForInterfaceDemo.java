package com.programs.day3;

public class MainClassForInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccessATMSampleInterface obj = new AccessATMSampleInterface();
		obj.cardNumber();
		obj.pinNumber();
		obj.BankName();
	}
}
