package com.programs.day3;

public class LocalBank  extends GlobalBank{
	int lbid;
	public LocalBank() {
		super(); // access the parent class constructor
		
	}
	
	
}
