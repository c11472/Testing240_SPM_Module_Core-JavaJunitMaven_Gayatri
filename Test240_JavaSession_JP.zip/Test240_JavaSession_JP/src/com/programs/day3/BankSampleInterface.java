package com.programs.day3;

public interface BankSampleInterface {
	abstract void BankName();

}
