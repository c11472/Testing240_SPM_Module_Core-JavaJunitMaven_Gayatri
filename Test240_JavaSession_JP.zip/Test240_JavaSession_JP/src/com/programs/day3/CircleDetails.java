package com.programs.day3;

public class CircleDetails {
	private  int r;
	
	
 public int GetRadius() {
		return r; 
	}
	
	public void setRadius(int rad) {
		this.r=rad;
	}
}
