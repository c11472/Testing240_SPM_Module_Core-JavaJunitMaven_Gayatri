package com.programs.day3;

public class StaticClassDemo {

}
