package com.programs.day1;
/*
 * Do - While Loop
 */
public class DoWhileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        int i =10;
        
        do {
        	System.out.println(i);
        	i++;
        }
        
        while(i<=20);
      
	}

}
