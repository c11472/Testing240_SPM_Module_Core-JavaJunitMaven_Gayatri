package com.programs.day1;
/*
 * Create method library
 */
public class Libraryday1 {
	
	public void namemethod(){
		System.out.println("This is a sample method !");
				}
	
	public void namemethod1(){
		System.out.println("This is a sample method2 !");
				}
	
	public void namemethod3(){
		System.out.println("This is a sample method3 !");
				}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
