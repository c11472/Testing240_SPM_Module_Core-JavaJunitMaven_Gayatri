package com.programs.day1;

public class day1p5_init1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Hard coded values
		
		
		int empid = 11472;
		
		
        String ename = "Gayatri Mishra";		
		
		double sal = 56080.50;
		
		double increment = 10000.50;
		
		// int
		// double
		// float
		// String ----- class
		
		System.out.println(ename + "  " + empid + "  "+ sal);
		
		System.out.println(sal+increment);
		

	}

}
