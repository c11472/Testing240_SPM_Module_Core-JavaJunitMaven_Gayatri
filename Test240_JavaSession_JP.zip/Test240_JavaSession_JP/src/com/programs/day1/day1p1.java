package com.programs.day1;
/*
 * First code in java
 */
public class day1p1 {
   //main method
	public static void main(String[] args) {
		
		// main block
		
		System.out.println("Hello There ! We are in Java Day1"); // display the values in console

	}
	
	// define user defined methods 

}
