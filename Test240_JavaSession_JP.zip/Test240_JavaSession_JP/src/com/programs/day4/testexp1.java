package com.programs.day4;

import java.util.Scanner;

public class testexp1 {
	public static void main(String args[]) {
		Scanner c = new Scanner(System.in);
		/*String s="";
		int p;
		p = (Integer) null;
		//System.out.println(s);*/
		
		int num;
		num=c.nextInt();
		System.out.println(num);
		
		
		
	}

}
