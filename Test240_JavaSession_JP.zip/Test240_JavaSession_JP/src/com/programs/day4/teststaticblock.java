package com.programs.day4;

public class teststaticblock {
	//int num=10;
	static{
		int num=10;

		System.out.println("I am in static block:" + num); //1
	}

	static {
		System.out.println("Hello"); //2
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stu

	}

}


