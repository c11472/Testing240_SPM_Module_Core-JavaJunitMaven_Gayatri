package com.programs.day4;

public class maxval {
	public static void main(String args[]) {
		int p = Integer.max(10, 500); 
		
		System.out.println(p);

		
	}

}
