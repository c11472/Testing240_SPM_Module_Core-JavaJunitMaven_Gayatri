package com.programs.day5;

import java.util.ArrayList;

public class ArrayListDemoP1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// How to create a array list
		
		ArrayList<Integer> alist = new ArrayList();
		
		alist.add(14);
		
		alist.add(23);
		alist.add(78);
		alist.add(1000);
		alist.add(10);
		alist.add(11);
		
		//System.out.println(alist);
		//for-each
		for(Object i:alist) {
			System.out.println(i+ " ");
		}
		
		System.out.println("Total numbers stored in list"+ " "+alist.size());
		//normal for loop
		for(int i=0;i<=alist.size()-1;i++) {
			System.out.println(alist.get(i));
		}
		
		int val3=alist.get(3);
		System.out.println(val3);
		
		int val1=alist.get(0);
		System.out.println(val1);
		
		
		
		
		
		
		

	}

}
