package com.programs.day5;

import java.util.ArrayList;
import java.util.Scanner;

public class TakeInputForArrayListP2 {

	public static void main(String[] args) {
		
		ArrayList <Integer> al = new ArrayList();
	    Scanner c = new Scanner(System.in);
		
		int counts = c.nextInt();
		int i;
		 System.out.println("Enter values to the list");
		   
         for( i=0;i<=5;i++) {
        	 al.add(c.nextInt());
        	// System.out.println(al.get(i));
         }
         
         
        for(i=0;i<=5;i++) {
        	System.out.print(al.get(i) + " ");
        	
        }
        System.out.println(al);
		 
		

	}

}
