package com.programs.day5;

import java.util.ArrayList;
import java.util.Collections;

public class GetDataFrmArrayToArrayListP6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arrnumbers[] = {1,2,3,4,5,6,7,8,9};
		
		ArrayList <Integer> al = new ArrayList();
		
		
		for(int i=0;i<=arrnumbers.length-1;i++) {
			al.add(arrnumbers[i]);
		}
		//System.out.println(arrnumbers);//1,2,3,4,5,6,7,8,9
		
		for(int i:arrnumbers) {
			System.out.print(i+ " ");
		}
		
     int p= Collections.max(al);
     System.out.println(p+ " MAX VAL");
     
     int min = Collections.min(al);
     System.out.println(min + "MIN VAL ");
      
      Collections.sort(al);
      for(int i:al) {
    	  System.out.print(i+ " ");
      }
	
	}

}
