package com.programs.day5;

import java.util.ArrayList;
import java.util.Iterator;


public class ArrayListValidationP3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Double> list = new ArrayList();
		
		list.add(67.0);
		list.add(45.0);
		list.add(10.6);
		
		System.out.println(list);
		
		
		if(list.contains(100.5)) {
			System.out.println("present");
		}
		else {
			System.out.println("not present");
		}
		
		
		list.add(2, 99.9);
		System.out.println(list);
		
		list.remove(2);
		System.out.println(list);
		
		// Traverse the list using iterator
		
		Iterator it =  list.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		

	}

}
