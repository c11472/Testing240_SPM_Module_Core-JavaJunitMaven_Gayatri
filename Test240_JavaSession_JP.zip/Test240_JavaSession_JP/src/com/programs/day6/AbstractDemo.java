package com.programs.day6;

public abstract class AbstractDemo {
	
	// abstarct class will hold abstract methods
	  // display message
      abstract void Disp_Data();  // abstract method
      //calculate the factorial
      abstract int numfact(); // returns int
      
	

}
