package com.programs.day6;

import java.util.HashMap;
import java.util.Map;

public class HashMap_TakDataFromArray_d2 {
	public static void main(String args[]) {
		HashMap <Integer,String> hs 
		   = new HashMap <Integer,String>();
		
		int Keyshm[] = {101,297,334};
		String Valueshm[] = {"Mumbai","Test","Test"};
		
		for(int i=0;i<=Keyshm.length-1;i++) {
			hs .put(Keyshm[i], Valueshm[i]);
			
		}
		
		System.out.println(hs);
		
		for (Map.Entry m : hs.entrySet()) {
			System.out.println(m.getKey() + " "+m.getValue());
		}
		String strval = hs.get(297);
		
		
		System.out.println(hs.keySet());
		
		System.out.println(hs.values());
		
		System.out.println(hs.containsValue("Chennai"));
		
		System.out.println(hs.containsKey(999));
		
		System.out.println(hs.entrySet());//[101=Mumbai, 297=Test, 334=Auto]
		
        
	}

}
