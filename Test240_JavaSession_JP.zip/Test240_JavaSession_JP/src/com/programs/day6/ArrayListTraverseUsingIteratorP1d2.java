package com.programs.day6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayListTraverseUsingIteratorP1d2 {
	public static void main(String args[]) {
		ArrayList <Integer> al 
		   = new ArrayList();
		
		ArrayList <Integer> al1 
		   = new ArrayList();
		
		
		Scanner c = new Scanner(System.in);
		int input=c.nextInt();
		
		
		al.add(1001);
		al.add(200);
		al.add(302);
		al.add(22);
		al.add(50);
		al.add(500);
		al.add(555);
		
		System.out.println(al); // String
		
		//Iterator for traversal 
		
		Iterator  it = al.iterator(); 
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
		// check whether the input is present in ArrayList
		
		if(al.contains(input)) {
			System.out.println("present");
		}
		else {
			System.out.println("Not preset !");
		}
		
		
		al1.addAll(al);
		
		System.out.println(al1);
		
		al.add(4, 9999);
		System.out.println(al);
		
		al.remove(2);
		System.out.println(al);
		
		
		System.out.println(al.contains(al1));

	}

}
