package com.programs.day6;

import java.util.StringTokenizer;
/*****
 * StringTokenizer is a class in util package
 * StringTokenizer will help us to  extract the words for formatted strings.
 * Constructor :
 *    StringTokenizer stoken = new StringTokenizer(strvariable,"delimiter");
 * Methods :
 *    stoken.hasMoreTokens()
 *    stoken.nextToken()
 *    stoken.hasMoreElement()
 *    stoken.nextElement()
 * @author Hp
 *
 */
public class StringTokenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "192.168.147.23";
		StringTokenizer strtoken = new StringTokenizer(str,".");
	    int count = strtoken.countTokens(); 
	    System.out.println(count);

		while(strtoken.hasMoreTokens()) {
			System.out.println(strtoken.nextToken());
		}
	//	System.out.println(count);
			

	}

}
