package com.programs.day6;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListDemod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> list = new<Integer> LinkedList();
		LinkedList<Integer> list2 = new<Integer> LinkedList();
		list.add(19);
		list.add(34);
		list.add(45);
		list.add(34);
		list.addFirst(999);
		list.removeLast();
		System.out.println(list.peek());
		System.out.println(list.peekLast());
		
		System.out.println(list);
      /*
		
		list.addFirst(null);
		list.addLast(null);
		
		list.removeFirst()
		list.removeLast()
		
		list.descendingIterator()
		
		list.peekFirst()
		list.peekLast()
		list.pollFirst()
		list.pollLast()
		
		list.pop()
		list.push(null);
*/
		
		
		
		Collections.sort(list);
		
		list.remove(2);
		
		Iterator it = list.descendingIterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
	}

}
