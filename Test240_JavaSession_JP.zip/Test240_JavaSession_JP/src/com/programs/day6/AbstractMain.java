package com.programs.day6;

public class AbstractMain {
//Abstract class does not support multiple inheritance
//Interface supports multiple inheritance
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccessAbstract object1 = new AccessAbstract();
		
		object1.Disp_Data();
		int factorialval =object1.numfact();
		System.out.println(factorialval);

	}

}
