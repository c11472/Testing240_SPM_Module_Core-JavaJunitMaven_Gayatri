package com.programs.day6;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap <Integer,String> hs 
		   = new HashMap <Integer,String>();
		hs.put(200, "Bangalore");
		
		hs.put(101, "Mumbai");
		hs.put(405, "Kolkata");
		hs.put(302, "Chennai");
		hs.put(203, "Hyderabad");
		System.out.println(hs);
		
		for (Map.Entry m : hs.entrySet()) {
			System.out.println(m.getKey() + " "+m.getValue());
			
		}
		

	}

}
