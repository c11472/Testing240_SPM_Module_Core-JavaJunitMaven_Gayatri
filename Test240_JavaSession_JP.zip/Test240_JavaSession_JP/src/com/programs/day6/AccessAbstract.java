package com.programs.day6;

public class AccessAbstract  extends AbstractDemo{

	void Disp_Data() {
		System.out.println("this is the message from abstract method1");
		
	}

	int numfact() {
		int num=5;
		int fact=1;
		for(int i=1;i<=num;i++) {
			fact = fact*i;
			
			
		}
		return fact;
	}

}
