package com.programs.day6;

import java.util.HashSet;

public class HashSetDemod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashSet <Integer> hs = new HashSet();
   
		hs.add(78);
		hs.add(67);
		hs.add(33);
		hs.add(2);
		hs.add(67);
		hs.add(999);
		hs.add(999);
		hs.add(999);
		hs.add(2);
		hs.add(33);
		hs.add(6908);
		hs.remove(33);

		
		System.out.println(hs);
		
		
		for(int i:hs) {
			System.out.println(i+ " ");
		}
		
		String res = hs.toString();
		System.out.println(res);
		
		Object arr[] = new Object[5];
		
		arr = hs.toArray();
		
		for(Object i:arr) {
			System.out.print(i+ " ");
		}
	}

}
