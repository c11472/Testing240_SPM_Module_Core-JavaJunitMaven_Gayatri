package com.programs.day2;

public class day2_p8StaticMethodsInJava {
	//method definition
	
	public static int sampleDataTest() {
		System.out.println("Sample data to display in console !");
		return 1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sampleDataTest(); // method call

	}

}
