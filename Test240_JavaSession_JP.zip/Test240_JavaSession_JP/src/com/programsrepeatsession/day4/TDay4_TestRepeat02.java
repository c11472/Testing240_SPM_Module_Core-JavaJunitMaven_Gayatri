package com.programsrepeatsession.day4;

public class TDay4_TestRepeat02 {
	
	public static void main(String args[]) {
		// Hard coded values
		int number = 99;
		double percentage=98.90;
		String name = "QA-SDET";
		System.out.print(number); //99 
		System.out.print(percentage);//98.9

		System.out.print(name);//QA-SDET

		
		
		
	}

}
