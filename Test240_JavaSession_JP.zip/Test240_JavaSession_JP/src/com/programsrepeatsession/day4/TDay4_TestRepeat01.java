package com.programsrepeatsession.day4;

public class TDay4_TestRepeat01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      //System.out.println("Hello");
	      
	      System.out.println("Hello world");
	      System.out.print("Hello");
	      System.out.print("Hello123");
	      
	}

}
