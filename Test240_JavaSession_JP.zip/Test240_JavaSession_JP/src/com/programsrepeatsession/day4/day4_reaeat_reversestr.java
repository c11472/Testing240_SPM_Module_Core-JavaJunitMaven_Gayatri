package com.programsrepeatsession.day4;

public class day4_reaeat_reversestr {
	
	public static void main(String args[]) {
		String value = "Hello we are working on String class";
		
		StringBuffer sb = new StringBuffer(value);
		System.out.println(sb); //Hello we are working on String class
		
		StringBuffer sb1=sb.reverse();
		System.out.println(sb1);
		
	}

}
