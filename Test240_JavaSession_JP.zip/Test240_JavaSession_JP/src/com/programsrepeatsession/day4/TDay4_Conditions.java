package com.programsrepeatsession.day4;

public class TDay4_Conditions {
	public static void main(String args[]) {
		
		String city = "BBSR";
		String c="1234";
		
		int num=100;
		int num2=100;
		
		if(city.equals(c)) {
			System.out.println(city);
		}
		else {
			System.out.println(c);
		}
		
	}

}
