package com.programsrepeatsession.day4;

import java.util.Scanner;

//Enter your name and employee id
public class TDay4_TestRepeat03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//lang
		//util<---- Scanner
		//
		//
		
		String name;
		String empid;
		// Taking input
		Scanner  obj = new Scanner(System.in);
		
		System.out.println("Enter the details");
		
		name = obj.nextLine();
		empid = obj.nextLine();
		System.out.println(name + "  " +  empid);

	}

}
