package com.programsrepeatsession.day4;

public class StringCode {
	public static void main(String args[]) {
		String str = "Automation batch code 240 Pune";
		
		System.out.println(str.hashCode());
		
		//000000
		//565677
		//-900000
		//Non of these
		//b or c
	}

}
