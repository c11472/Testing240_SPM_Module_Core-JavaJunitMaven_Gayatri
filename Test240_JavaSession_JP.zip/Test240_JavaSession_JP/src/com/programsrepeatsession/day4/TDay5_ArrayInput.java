package com.programsrepeatsession.day4;

public class TDay5_ArrayInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
