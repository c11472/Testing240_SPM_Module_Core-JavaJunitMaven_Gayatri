package com.programsrepeatsession.day4;
// Conditions , oerators
public class TDay4_TestRepeat04 {
	public static void main(String args[]) {
		// + ,-,*,/
		int num=98 ;
		int num2=89;
		int num3= num+num2;
        System.out.println(num3);
        double sal = 45000.60;
        double upsal = (sal * 30/100)+ sal;
        System.out.println(upsal);
        
       String city = "Pune";
       String countrycode="IND09100Pune";
       String countrycode1="Ind09100pune";

       
       countrycode.charAt(5); 
       System.out.println(countrycode.concat(city)); //IND09100Pune
       System.out.println(countrycode.contains("&*")); //false
       if(countrycode.endsWith(city)) {
    	   System.out.println("valid data");
       }
       else {
    	   System.out.println("Invalid data");
       }
       
       if(countrycode.equals(countrycode1)) {
    	   System.out.println("valid data");
       }
       else {
    	   System.out.println("Invalid data");
       }
       
       if(countrycode.equalsIgnoreCase(countrycode1)) {
    	   System.out.println("valid data");
       }
       else {
    	   System.out.println("Invalid data");
       }
        
	}

}
