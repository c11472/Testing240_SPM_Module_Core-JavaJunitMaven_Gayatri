package com.programsrepeatsession.day4;

public class TDay4_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	Object arr[] = {123,"test",98.09,'G'};
		
		for(int i=arr.length-1 ;i>=0;i--) {
			System.out.println(arr[i]);
		}
		
		// 123 test 98.09 G
		// Complillation error
		// G 98.09 test 123
		// NOA*/
		
		/*int arr[] = {78,56,34,12,5 ,109,32};
		
		for(int i = 0;i<=arr.length-1;i++) {
			System.out.println(arr[i]+5);
		}
		
		//78 56 34 12 5 109 32 17 114 37
		//Error
		//ArrayIndexOutofBounds
		// NOA */
		
		String arr[] = {"Test1","Data1","Test2","Dat2"};
		
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[2]+ arr[3]);
		}
		
		//Test1 Data1 Test2 Data2
		//Data2 Test2 Data1 Test1
		//NULL NULL NULL NULL
		//ArrayIndexOutOfBounds
	}

}
