package com.programsrepeatsession.day4;

public class StringToArray {
	public static void main(String args[]) {
		String city[] = {"Good morning","Mumbai"};
		if(city.toString().contains("Good morning")) {
			System.out.println("Present");
		}
		else {
			System.out.println("absent");
			
		}
	}

}
