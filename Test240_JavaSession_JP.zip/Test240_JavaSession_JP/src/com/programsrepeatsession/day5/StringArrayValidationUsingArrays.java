package com.programsrepeatsession.day5;

import java.util.Arrays;

public class StringArrayValidationUsingArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String values[] = {"test","automation","using","selenium","and","java"};
		
		String resstr = Arrays.toString(values);
		System.out.println(resstr);
		if(resstr.contains("QTP")) {
			System.out.println("city is present");
		}
		else {
			System.out.println("not present !");
		}

	}

}
