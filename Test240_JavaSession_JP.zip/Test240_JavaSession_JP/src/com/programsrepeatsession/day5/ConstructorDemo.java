package com.programsrepeatsession.day5;

public class ConstructorDemo {
	//Constructor is used to init the class members
	
	String emploc;
	int empid;
	double empsal;
	
	
	ConstructorDemo(){
		emploc="BHDC";
		empid=11472;
		empsal=34000.50;	
	}
	
	ConstructorDemo(String name , int id , double sl){
		this.emploc=name;
		this.empid=id;
		this.empsal=sl;
		
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ConstructorDemo firstconst = new ConstructorDemo();
		
		System.out.println(firstconst.emploc); //BHDC
		System.out.println(firstconst.empid);  //11472
		
		ConstructorDemo secondconst = new ConstructorDemo("testname",11471 ,56000.56);
		
		System.out.println(secondconst.emploc); //testname
		System.out.println(secondconst.empid); //11472
	
	}
	

}
