package com.programsrepeatsession.day5;

import java.util.Arrays;

public class ArraysDemo {

	public static void main(String[] args) {
		
		int arr[] = {10,45,56,34,5,78,90,100,32,11};
		int arr1[] = {10,45,56,34,51,78,90,100,32,11};
		
		int brr[] = new int[10];
		for(int i:arr) {
			System.out.println(i+ " ");
		}
		
		int indexnumber=Arrays.binarySearch(arr, 34);
		System.out.println(indexnumber);
		
		if(Arrays.equals(arr, arr1)) {
			System.out.println("same values");
		}
		else {
			System.out.println("different values");
		}
		
		
      int result[]= Arrays.copyOfRange(arr1, 0,arr1.length-1);		
      
      for(int i:result) {
    	  System.out.println(i+ " ");
    	  
      }
    Arrays.fill(arr1,2,5,7); 
    for(int i:arr1) {
    	System.out.print(i+ " ");
    }
    
    String values=  Arrays.toString(arr1);
    System.out.println(values);
		
		
		

	}

}
