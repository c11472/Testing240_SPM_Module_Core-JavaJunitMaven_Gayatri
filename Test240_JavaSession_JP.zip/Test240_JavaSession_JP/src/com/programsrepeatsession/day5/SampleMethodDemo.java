package com.programsrepeatsession.day5;

import java.util.Arrays;

public class SampleMethodDemo {
   //define method
	//
	public double sort_my_array() {
		int arr[] = {11,45,23,7,49,05};
		Arrays.sort(arr);
		for(int  i: arr) {
			System.out.println(i+ " ");
		}
		
		return 78.78;
		
	}
	
	
	
	
	
	public static void main(String args[]) {
		// call the methods 
		
		SampleMethodDemo obj = new SampleMethodDemo();
		obj.sort_my_array();
		
	}
	//
	
	//define method
}
