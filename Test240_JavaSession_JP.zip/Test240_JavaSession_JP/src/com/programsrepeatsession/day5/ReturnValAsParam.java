package com.programsrepeatsession.day5;

public class ReturnValAsParam {
	
	int fact;
	int num=5;
	
	
	public int calculatefact() {
		//int fact=1;
		//int num=5;
		fact=1;
		for(int i=1;i<=num;i++) {
			fact=fact*i;
			
		}
		System.out.println(fact);
		
		
		
		return fact;
		
	}
	
	
	
	
	public void passfact(int fact) {
		
		int val = calculatefact();
	
		System.out.println(val+10);
		
	}
	public static void main(String args[]) {
		ReturnValAsParam obj = new ReturnValAsParam();
		obj.calculatefact();
		obj.passfact(1);
		
		
		
	}

}
