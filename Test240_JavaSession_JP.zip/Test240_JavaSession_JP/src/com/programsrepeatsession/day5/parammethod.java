package com.programsrepeatsession.day5;

import java.util.Scanner;

public class parammethod {
	
	Scanner c = new Scanner(System.in);
	
	public void loginvalidation(String username,String password) {
		String u1,p1;
		System.out.println("Enter your credentials");
		
		String unm = "admin";
		String pwd = "admin123";
		
		System.out.println("Enter user name");
		u1=c.next();
		
		System.out.println("Eneter password");
		p1=c.next();
		
		if((u1.equals(unm))&&(p1.equals(pwd))) {
			System.out.println("successful login");
		}
		else {
			System.out.println("wrong credentials");
		}		
	
		
	}
	
	
	public static void main(String args[]) {
		parammethod validatedata = new parammethod();
		
		validatedata.loginvalidation("testuser1", "testpassword1");
		
	}

}
