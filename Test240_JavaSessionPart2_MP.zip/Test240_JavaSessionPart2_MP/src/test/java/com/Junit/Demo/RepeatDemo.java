package com.Junit.Demo;

import static org.junit.Assert.*;

import org.junit.Test;

public class RepeatDemo {

	@Test
	public void test() {
		System.out.println("hello !");
	}

}
