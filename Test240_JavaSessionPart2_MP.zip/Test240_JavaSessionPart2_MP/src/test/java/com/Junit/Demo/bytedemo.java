package com.Junit.Demo;

import java.time.LocalDateTime;

public class bytedemo {
	public static void main(String args[]) {
	    LocalDateTime myObj = LocalDateTime.now();
	    System.out.println(myObj);

 	}

}
