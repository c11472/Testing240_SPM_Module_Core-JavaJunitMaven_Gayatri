package com.Junit.Demo;

class scope 
{
    public static void main(String args[]) 
    {
        int x;
        x = 5;
        {
        int y = 6;
        System.out.print(x + " " + y);
        }
        System.out.println(x + " " + y);
    } 
}
