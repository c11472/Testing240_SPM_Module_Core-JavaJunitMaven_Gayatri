package com.Junit.Demo;

class output {
    public static void main(String args[]) 
    {
        double a, b,c;
        a = 3.0/0;
        b = 0/4.0;
        c=0/0.0;

    System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    } 
}
