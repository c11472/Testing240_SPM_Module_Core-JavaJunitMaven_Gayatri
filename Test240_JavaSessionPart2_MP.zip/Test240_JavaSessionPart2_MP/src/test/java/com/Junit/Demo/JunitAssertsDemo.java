package com.Junit.Demo;

import org.junit.Assert;
import org.junit.Test;

public class JunitAssertsDemo {
	@Test
	public void TestAssertString() {
		String exp1 = "Let us C";
		String act1 ="Let us C";
		
		Assert.assertSame(exp1, act1);
		System.out.println("Hello assert string !");
	
		
		
		
	}
	
	@Test
	public void TestAssertArray() {
		int numbers_exp[] = {10,34,5,81,21,67};
		int numbers_act[] = {10,34,5,81,21,67,10,45};
		System.out.println("Hello assert array1 !");
		
		Assert.assertArrayEquals(numbers_exp, numbers_act);
		System.out.println("Hello");

		
	}
	@Test
	public void TestAssertDouble() {
		double d1 = 89.7;
		double d2=88.76;
		//Assert.assertEquals(d1, d2);
		
		Assert.assertEquals(d1, d2);
		
		
	}
	@Test
	public void TestAssertBoolean() {
		
		boolean val_exp = true;
		boolean val_act = false;
		Assert.assertEquals(val_exp,val_act);

		
		
	}
	@Test
	public void TestAssertInt() {
		int num_exp=67;
		int num_act=67;
		
		Assert.assertEquals(num_exp,num_act);

		
	}

}
