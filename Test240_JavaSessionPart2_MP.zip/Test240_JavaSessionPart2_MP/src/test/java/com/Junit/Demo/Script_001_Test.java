package com.Junit.Demo;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;



public class Script_001_Test {
	
	//Scanner c = new Scanner(System.in);

	@Test //Default annotation
	public void Atest() {
		String input = "132453452";
		StringBuffer sb = new StringBuffer(input);
		StringBuffer sb1=sb.reverse();
		System.out.println(sb1);
		
		
		
	}
	@Test
	public void Btest2() {
		System.out.println("Hello There2 !");
	}
	@Ignore
	public void Btest3() {
		System.out.println("Hello There3 !");
	}
	@Test
	public void Btest4() {
		System.out.println("Hello There4 !");
	}
	@Test
	public void Btest() {
		System.out.println("Hello There !");
	}
	
	@Before
	public void Setup() {
		System.out.println("Test before");
		
	}
	
	@After
	public void TearDown() {
		System.out.println("Test after");
	}
	@BeforeClass
	public static void bclass() {
		System.out.println("1344533");
		
	}
	@AfterClass
	public static void aclass() {
		System.out.println("6756787");
		String s = "hello";
		String s1 = "hello";
		Assert.assertEquals( s, s1);
		
	}

}
